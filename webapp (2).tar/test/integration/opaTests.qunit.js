sap.ui.define([
    "./NavigationJourney"
]);